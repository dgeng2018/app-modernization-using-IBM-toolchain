# PHP Hello World Sample

This application demonstrates a simple, reusable PHP web application.

## Run the app locally

1. Download and extract [PHP][]
1. cd into this project's root directory
1. Run `php -S localhost:8000` to start the app using the built-in development web server
1. Access the running app in a browser at <http://localhost:8000>

[PHP]: http://php.net/downloads.php
